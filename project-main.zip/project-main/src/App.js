import React, { useState, useEffect } from "react";

// Game constants
const GRID_ROWS = 15; // Number of rows in the grid
const GRID_COLUMNS = 20; // Number of columns in the grid
const SPEED = 100; // Animation speed in milliseconds

const App = () => {
  const [wavePosition, setWavePosition] = useState(0); // Current wave position
  const [direction, setDirection] = useState(1); // 1 = moving right, -1 = moving left
  const [currentColor, setCurrentColor] = useState("green"); // Current wave color
  const [colorChangeInterval, setColorChangeInterval] = useState(15000); // Interval for color change in ms
  const [isGameRunning, setIsGameRunning] = useState(true); // Game state to start/stop animation
  const [score, setScore] = useState(0); // Score tracking
  const [moves, setMoves] = useState(0); // Number of moves made
  const [gameOver, setGameOver] = useState(false); // Game over state
  const [colorCycleComplete, setColorCycleComplete] = useState(false); // Track if color cycle is complete

  // Use this state to track if the game has ended
  const [gameEnded, setGameEnded] = useState(false); // Whether the game has been manually ended via tap

  useEffect(() => {
    if (!isGameRunning || gameOver || gameEnded) return; // Stop animation if game is over or manually ended

    // Wave movement logic
    const interval = setInterval(() => {
      setWavePosition((prevPosition) => {
        const nextPosition = prevPosition + direction;

        if (nextPosition >= GRID_COLUMNS) {
          setDirection(-1); // Change direction to left immediately when reaching right boundary
          return prevPosition; // Stay at the boundary
        }

        if (nextPosition < 0) {
          setDirection(1); // Change direction to right immediately when reaching left boundary
          return prevPosition; // Stay at the boundary
        }

        return nextPosition; // Continue moving in the current direction
      });

      // Update score and moves on every successful wave movement
      setMoves((prevMoves) => prevMoves + 1);
      setScore((prevScore) => prevScore + 10); // Increase score by 10 per move
    }, SPEED);

    return () => clearInterval(interval); // Cleanup interval on component unmount
  }, [direction, isGameRunning, gameOver, gameEnded]);

  useEffect(() => {
    if (!isGameRunning || gameOver || gameEnded) return;

    // Color changing logic
    const colorInterval = setInterval(() => {
      setCurrentColor((prevColor) => {
        // Cycle through colors: green -> blue -> red -> green
        if (prevColor === "green") return "blue";
        if (prevColor === "blue") return "red";
        return "green";
      });

      // Check if we've cycled through all three colors
      setColorCycleComplete((prevCycle) => {
        if (!prevCycle && currentColor === "red") {
          // If we are currently showing red and the cycle is completed, terminate the game
          setGameOver(true);
          return true; // Color cycle complete
        }
        return prevCycle;
      });

      // Alternate the interval time between 15 seconds and 3 seconds
      setColorChangeInterval((prevInterval) =>
        prevInterval === 15000 ? 3000 : 15000
      );
    }, colorChangeInterval);

    return () => clearInterval(colorInterval); // Cleanup interval on component unmount
  }, [colorChangeInterval, isGameRunning, gameOver, currentColor, gameEnded]);

  // Style for each square in the grid
  const getSquareStyle = (row, col) => {
    const distanceFromWave = Math.abs(col - wavePosition); // Distance from wave center
    const maxDistance = 5; // Maximum distance for wave effect
    const opacity = Math.max(0, 1 - distanceFromWave / maxDistance); // Gradual fade
    const colorShade = Math.max(50, 255 - distanceFromWave * 40); // Gradient effect

    return {
      width: "30px",
      height: "30px",
      margin: "2px",
      backgroundColor: `rgba(${currentColor === "red" ? colorShade : 0}, ${
        currentColor === "green" ? colorShade : 0
      }, ${currentColor === "blue" ? colorShade : 0}, ${opacity})`,
      display: "inline-block",
      borderRadius: "2px",
      transition: "background-color 0.1s ease",
      border: "1px solid #444", // Border to make grid visible
      boxShadow: "0 0 5px rgba(255, 255, 255, 0.3)", // Add glow effect for a game feel
    };
  };

  // Handle click event on the grid to end the game
  const handleGridClick = () => {
    setGameEnded(true); // Manually end the game when the grid is clicked
    setGameOver(true); // Ensure game is over
  };

  // Reset game state after game over
  const resetGame = () => {
    setIsGameRunning(false); // Temporarily stop the game
    setWavePosition(0);
    setDirection(1);
    setScore(0);
    setMoves(0);
    setGameOver(false);
    setGameEnded(false); // Reset manual end state
    setColorCycleComplete(false); // Reset color cycle state
    setCurrentColor("green"); // Reset to initial color
    setColorChangeInterval(15000); // Reset color change interval

    // Restart the game by setting isGameRunning to true after the reset
    setIsGameRunning(true);
  };

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        height: "100vh",
        backgroundColor: "black",
        background: "linear-gradient(135deg, #1c1c1c, #2a2a2a)", // Background gradient
        overflow: "hidden",
        position: "relative",
      }}
      onClick={handleGridClick} // Click on the grid to terminate the game
    >
      {/* Game Control Buttons */}
      <div style={{ position: "absolute", top: "20px", zIndex: 1 }}>
        <button
          onClick={resetGame}
          style={{
            padding: "10px 20px",
            backgroundColor: "#444",
            color: "white",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer",
            fontSize: "16px",
            boxShadow: "0 0 10px rgba(255, 255, 255, 0.5)",
          }}
        >
          {gameOver ? "Restart Game" : isGameRunning ? "Pause Game" : "Start Game"}
        </button>
      </div>

      {/* Game Over Message */}
      {gameOver && (
        <div style={{ position: "absolute", top: "150px", zIndex: 1 }}>
          <h2 style={{ color: "white", fontSize: "3rem", textShadow: "2px 2px 8px rgba(255, 255, 255, 0.6)" }}>
            Game Over
          </h2>
          <h3 style={{ color: "white", fontSize: "1.5rem", textShadow: "1px 1px 5px rgba(255, 255, 255, 0.4)" }}>
            Final Score: {score}
          </h3>
        </div>
      )}

      {/* Score Display */}
      {!gameOver && (
        <div style={{ position: "absolute", top: "20px", left: "20px", zIndex: 1 }}>
          <h2 style={{ color: "white", fontSize: "1.5rem", textShadow: "2px 2px 8px rgba(255, 255, 255, 0.6)" }}>
            Score: {score}
          </h2>
        </div>
      )}

      {/* Render the grid */}
      <div style={{ display: "flex", flexDirection: "column" }}>
        {Array.from({ length: GRID_ROWS }).map((_, rowIndex) => (
          <div key={rowIndex} style={{ display: "flex" }}>
            {Array.from({ length: GRID_COLUMNS }).map((_, colIndex) => (
              <div
                key={`${rowIndex}-${colIndex}`} // Corrected key
                style={getSquareStyle(rowIndex, colIndex)}
              />
            ))}
          </div>
        ))}
      </div>

      {/* Game Title */}
      <h1
        style={{
          color: "white",
          fontSize: "2rem",
          textShadow: "2px 2px 8px rgba(255, 255, 255, 0.6)",
          position: "absolute",
          top: "40px",
        }}
      >
        Wave Animation Game
      </h1>
    </div>
  );
};

export default App;
